﻿# DarttIntegraForwood 1.0.0

## Requisitos do Sistema
- Windows 10 ou superior
- Microsoft Visual C++ Redistributable 2019 ou superior
- Drivers ODBC para SQL Server e PostgreSQL

## InstalaÃ§Ã£o

1. Extraia todos os arquivos para uma pasta de sua escolha
2. Instale os drivers ODBC necessÃ¡rios da pasta 'odbc_drivers' (se nÃ£o estiverem instalados)
3. Configure suas conexÃµes ODBC no Administrador de Fontes de Dados ODBC do Windows
4. Execute o arquivo 'dartt_integraforwood.exe'

## ConfiguraÃ§Ã£o

Na primeira execuÃ§Ã£o, acesse as configuraÃ§Ãµes do aplicativo para definir:
- ConexÃµes com bancos de dados (SQL Server e PostgreSQL)
- DiretÃ³rios de trabalho (XML, ESP)
- CÃ³digos de batismo e outros parÃ¢metros

## Suporte

Para suporte, entre em contato com o desenvolvedor.
